def get_message():
    return "Hello World!"

def print_message():
    print get_message()
